<?php
/**
 * Created by PhpStorm.
 * User: Nomad_Mystic
 * Date: 9/25/2015
 * Time: 8:59 PM
 */

$name = 'Keith Murphy';



?>
<!DOCTYPE html>
<head><title>Assignment One</title></head>
<body>
    <h1>Hello <?php echo $name; ?>, Welcome to CIS195P</h1>

</body>
</html>