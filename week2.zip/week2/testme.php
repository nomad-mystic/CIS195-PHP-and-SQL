<?php
/**
 * Created by PhpStorm.
 * User: Nomad_Mystic
 * Date: 10/1/2015
 * Time: 7:14 PM
 */
$Keith = 'Keith';
$_keith = 'Keith';

$this_is_the_naming_convention_of_this_class = 'Some Value';
$thisIsMyPreferredStyle = 'Some Value';

$radius = 5;
$volume = 23.54;
$are_you_happy = TRUE;

echo 'This is only the beginning <br>';
echo "The radius is $radius, and volume is $volume.<br>";

$first_name = $_GET['first'];
$last_name = $_GET['last'];

echo " Hello $first_name $last_name, welcome to PHP.<br>";