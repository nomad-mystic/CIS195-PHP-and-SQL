<!DOCTYPE html>
<html>
<head>
    <title>

    </title>
</head>
<body>
    <form action="testme.php" method="get">
        <table>
            <tr>
                <td>First Name:</td>
                <td><input  name="first" type="text" width="100"></td>
            </tr>
            <tr>
                <td>Last Name:</td>
                <td><input name="last" type="text" width="100"></td>
            </tr>
            <tr>
                <td colspan="2"><input type="submit" value="Submit"></td>
            </tr>
        </table>
    </form>
<div></div>
</body>
</html>